package com.mahamayajewellers.attendance

import android.app.Activity
import android.os.Bundle
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("attendance", MODE_PRIVATE) }
    private val employees = mutableListOf<Employee>()
    data class Employee(val id: String, var name: String, var mobile: String, var pin: String, var salary: Double, var admin: Boolean = false)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); seed(); login() }
    private fun seed() {
        employees.clear()
        employees += Employee("admin", "Admin", "9000000000", "9999", 0.0, true)
        employees += Employee("1", "Employee 1", "9000000001", "1234", 15000.0)
    }
    private fun layout() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 32, 28, 28) }
    private fun title(t: String) = TextView(this).apply { text=t; textSize=23f; setPadding(0,0,0,20) }
    private fun button(t: String) = Button(this).apply { text=t; isAllCaps=false }
    private fun date() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private fun login() {
        val l=layout(); l.addView(title("MAHAMAYA JEWELLERS\nAttendance Sheet"))
        val m=EditText(this).apply{hint="Mobile Number";inputType=2}
        val p=EditText(this).apply{hint="PIN";inputType=2}
        val b=button("Login"); l.addView(m);l.addView(p);l.addView(b)
        l.addView(TextView(this).apply{text="Demo Admin: 9000000000 / 9999\nDemo Employee: 9000000001 / 1234"})
        setContentView(l)
        b.setOnClickListener { val e=employees.find{it.mobile==m.text.toString().trim() && it.pin==p.text.toString().trim()}; if(e==null) Toast.makeText(this,"Mobile Number या PIN गलत है",Toast.LENGTH_SHORT).show() else if(e.admin) admin() else employee(e) }
    }
    private fun employee(e: Employee) {
        val l=layout(); val d=date(); val key="att_${d}_${e.id}"; l.addView(title("नमस्ते, ${e.name}"))
        val s=TextView(this).apply{text="आज: $d\nAttendance: ${prefs.getString(key,"Not Marked")}";textSize=18f};l.addView(s)
        listOf("Present","Half Day","Absent").forEach { v -> val b=button(v);l.addView(b);b.setOnClickListener{if(!prefs.contains(key)){prefs.edit().putString(key,v).apply();s.text="आज: $d\nAttendance: $v"}else Toast.makeText(this,"आज की attendance पहले से दर्ज है",Toast.LENGTH_SHORT).show()} }
        val h=button("Attendance History");l.addView(h);h.setOnClickListener{history(e)}
        val o=button("Logout");l.addView(o);o.setOnClickListener{login()};setContentView(l)
    }
    private fun history(e: Employee) {
        val l=layout();l.addView(title("${e.name} - Attendance History"));val t=TextView(this);val sb=StringBuilder();val c=Calendar.getInstance()
        repeat(366){val d=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(c.time);prefs.getString("att_${d}_${e.id}",null)?.let{sb.append("$d — $it\n")};c.add(Calendar.DAY_OF_YEAR,-1)}
        t.text=if(sb.isEmpty())"अभी कोई record नहीं है।" else sb.toString();l.addView(t);val b=button("Back");l.addView(b);b.setOnClickListener{employee(e)};setContentView(l)
    }
    private fun admin() {
        val l=layout();l.addView(title("Admin Dashboard"));l.addView(TextView(this).apply{text="Employees: ${employees.count{!it.admin}}";textSize=18f})
        val a=button("Add Employee");val m=button("Employee Management");val r=button("Monthly Salary Report");val o=button("Logout");listOf(a,m,r,o).forEach{l.addView(it)};setContentView(l)
        a.setOnClickListener{addEmployee()};m.setOnClickListener{manage()};r.setOnClickListener{report()};o.setOnClickListener{login()}
    }
    private fun addEmployee(){
        val l=layout();l.addView(title("Add Employee"));val n=EditText(this).apply{hint="Employee Name"};val m=EditText(this).apply{hint="Mobile Number";inputType=2};val p=EditText(this).apply{hint="PIN";inputType=2};val s=EditText(this).apply{hint="Monthly Salary";inputType=2};val save=button("Save Employee");val back=button("Back");listOf(n,m,p,s,save,back).forEach{l.addView(it)};setContentView(l)
        save.setOnClickListener{val sal=s.text.toString().toDoubleOrNull()?:0.0;if(n.text.isBlank()||m.text.length<10||p.text.isBlank()||sal<=0){Toast.makeText(this,"सभी details सही भरें",Toast.LENGTH_SHORT).show()}else{employees+=Employee(UUID.randomUUID().toString(),n.text.toString(),m.text.toString(),p.text.toString(),sal);admin()}};back.setOnClickListener{admin()}
    }
    private fun manage(){val l=layout();l.addView(title("Employee Management"));employees.filter{!it.admin}.forEach{e->val b=button("${e.name} • ${e.mobile} • ₹${e.salary.toInt()} — Remove");l.addView(b);b.setOnClickListener{employees.remove(e);manage()}};val back=button("Back");l.addView(back);back.setOnClickListener{admin()};setContentView(l)}
    private fun report(){val l=layout();l.addView(title("Monthly Salary Report"));val month=SimpleDateFormat("yyyy-MM",Locale.getDefault()).format(Date());val days=Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);val t=TextView(this);val sb=StringBuilder("Month: $month\n\n");employees.filter{!it.admin}.forEach{e->var p=0;var h=0;var a=0;for(d in 1..days){val ds=String.format(Locale.getDefault(),"$month-%02d",d);when(prefs.getString("att_${ds}_${e.id}",null)){"Present"->p++;"Half Day"->h++;"Absent"->a++}};val pay=(p+h*.5)*(e.salary/days);sb.append("${e.name}: P=$p, H=$h, A=$a, Payable=₹${"%.2f".format(pay)}\n")};t.text=sb.toString();l.addView(t);val b=button("Back");l.addView(b);b.setOnClickListener{admin()};setContentView(l)}
}
